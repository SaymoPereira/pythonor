# djangoecommerce
Projeto de didático utilizado para meu curso de Django
